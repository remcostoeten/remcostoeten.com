import React from 'react';
import { ChatHistory } from './ChatHistory';
import chatData from '../../apisprivate/proper/znew.json';
import { Message } from '../models/Message';

const messages: Message[] = chatData.messages.map((message) => ({
	id: message.id,
	sender: message.sender,
	text: message.text,
	timestamp: new Date(message.timestamp),
}));

const App: React.FC = () => {
	return (
		<div className='app'>
			<ChatHistory messages={messages} pageSize={10} />
		</div>
	);
};

export default App;
